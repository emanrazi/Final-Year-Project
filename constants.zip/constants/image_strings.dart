//splash screen images
const String SplashTopIcon = "images/splash1.png";
const String SplashImage = "images/splash1.png";

//onboarding screen images
const String OnBoardingImg1 = "images/onboarding1.png";
const String OnBoardingImg2 = "images/onboarding4withoutback.png";
const String OnBoardingImg3 = "images/onboarding13.png";
