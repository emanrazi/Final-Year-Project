const String appName = "PawBuddy";
const String appTagLine = "Because Every Pet\nDeserves A Buddy!";

// On Boarding Text
const String onBoardingTitle1 = "Track Pet Health";
const String onBoardingSubTitle1 =
    "Easily monitor your pet's health with real-time updates and smart insights.";

const String onBoardingTitle2 = "Understand Emotions";
const String onBoardingSubTitle2 =
    "Detect and analyze your pet’s emotions to better understand their needs.";

const String onBoardingTitle3 = "Smart Care & Tips";
const String onBoardingSubTitle3 =
    "Get personalized care tips and recommendations for a happier, healthier pet.";

const String onBoardingCounter1 = "1/3";
const String onBoardingCounter2 = "2/3";
const String onBoardingCounter3 = "3/3";
