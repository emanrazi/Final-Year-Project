import 'dart:ui';

import 'package:flutter/material.dart';

const PrimaryColor = Color(0xFFFFE400);
const SecondaryColor = Color(0xFF272727);
const AccentColor = Color(0xFF001BFF);

const WhiteColor = Colors.white;
const DarkColor = Colors.black;
const CardBgColor = Color(0xFFF7F6F1);

//OnBoarding Screen colors

const OnBoardingPage1Color = Colors.white;
const OnBoardingPage2Color = Color.fromARGB(255, 194, 244, 226);
const OnBoardingPage3Color = Color.fromARGB(255, 148, 222, 212);
