import 'package:fyp/src/providers/authntication_notifier.dart';
import 'package:provider/provider.dart';
import 'package:provider/single_child_widget.dart';

class AppProviders {
  static List<SingleChildWidget> providers = [
    ChangeNotifierProvider(
      create: (_) => AuthnticationNotifier(), // Add parentheses to create instance
    ),
  ];
}