import 'package:flutter/foundation.dart';

class AuthnticationNotifier extends ChangeNotifier {
  bool _isAuthenticated = false;
  String? _userId;
  String? _userEmail;
  
  bool get isAuthenticated => _isAuthenticated;
  String? get userId => _userId;
  String? get userEmail => _userEmail;
  
  void login(String userId, String userEmail) {
    _isAuthenticated = true;
    _userId = userId;
    _userEmail = userEmail;
    notifyListeners();
  }
  
  void logout() {
    _isAuthenticated = false;
    _userId = null;
    _userEmail = null;
    notifyListeners();
  }
}