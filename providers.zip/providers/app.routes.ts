import 'package:flutter/material.dart';
import 'loginPage.dart'; // Make sure the path is correct

class AppRoutes {
  static const String LoginRoute = '/Loginpage';

  static final Map<String, WidgetBuilder> routes = {
    LoginRoute: (context) => Loginpage(),
  };
}
