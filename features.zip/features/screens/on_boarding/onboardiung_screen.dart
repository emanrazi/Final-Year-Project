import 'package:flutter/material.dart';
import 'package:fyp/src/features/screens/pages/intropage.dart';
import 'package:get/get.dart';
import 'package:liquid_swipe/liquid_swipe.dart';
import 'package:fyp/src/features/controller/onboarding_controller.dart';
import 'package:fyp/src/features/screens/pages/loginPage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class OnBoardingScreen extends StatefulWidget {
  const OnBoardingScreen({Key? key}) : super(key: key);

  @override
  State<OnBoardingScreen> createState() => _OnBoardingScreenState();
}

class _OnBoardingScreenState extends State<OnBoardingScreen> {
  // Controller for onboarding pages
  final obcontroller = Get.put(OnboardingController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        alignment: Alignment.center,
        children: [
          // Liquid Swipe pages
          Obx(() {
            return LiquidSwipe(
              pages: obcontroller.pages,
              liquidController: obcontroller.controller,
              slideIconWidget:
                  obcontroller.currentPage.value ==
                          obcontroller.pages.length - 1
                      ? null
                      : const Icon(Icons.arrow_back_ios),
              enableSideReveal: true,
              enableLoop: false,
              onPageChangeCallback: obcontroller.onPageChangeCallback,
            );
          }),

          // Next / Get Started Button
          Obx(() {
            return Positioned(
              bottom: 60.0,
              child:
                  obcontroller.currentPage.value ==
                          obcontroller.pages.length - 1
                      ? ElevatedButton(
                        onPressed: () async {
                          // Mark onboarding as seen
                          SharedPreferences prefs =
                              await SharedPreferences.getInstance();
                          await prefs.setBool('seenOnboarding', true);

                          // Go to LoginPage
                          Get.off(
                            () => const IntroHomePage(),
                            transition: Transition.circularReveal,
                            duration: const Duration(milliseconds: 800),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.teal,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 40,
                            vertical: 15,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                        child: const Text(
                          "Get Started",
                          style: TextStyle(fontSize: 18, color: Colors.white),
                        ),
                      )
                      : OutlinedButton(
                        onPressed: () => obcontroller.animateToNextSlide(),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Colors.teal),
                          shape: const CircleBorder(),
                          padding: const EdgeInsets.all(15),
                        ),
                        child: Container(
                          padding: const EdgeInsets.all(20),
                          decoration: const BoxDecoration(
                            color: Colors.teal,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.white,
                          ),
                        ),
                      ),
            );
          }),

          // Skip Button (hidden on last page)
          Obx(() {
            return obcontroller.currentPage.value ==
                    obcontroller.pages.length - 1
                ? const SizedBox.shrink()
                : Positioned(
                  top: 50,
                  right: 20,
                  child: TextButton(
                    onPressed: () async {
                      SharedPreferences prefs =
                          await SharedPreferences.getInstance();
                      await prefs.setBool('seenOnboarding', true);

                      Get.off(
                        () => const Loginpage(),
                        transition: Transition.rightToLeft,
                        duration: const Duration(milliseconds: 800),
                      );
                    },
                    child: const Text(
                      'Skip',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                );
          }),

          // Dots indicator
          Obx(
            () => Positioned(
              bottom: 20,
              child: AnimatedSmoothIndicator(
                activeIndex: obcontroller.currentPage.value,
                count: obcontroller.pages.length,
                effect: const WormEffect(
                  activeDotColor: Colors.teal,
                  dotColor: Colors.grey,
                  dotHeight: 5.0,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
