import 'package:flutter/material.dart';
import 'package:fyp/src/features/models/onboarding_model.dart';

class OnBoardingPageWidget extends StatelessWidget {
  const OnBoardingPageWidget({super.key, required this.model});

  final OnBoardingModel model;

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Container(
      padding: const EdgeInsets.all(30.0),
      color: model.bgColor,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        mainAxisSize: MainAxisSize.max,
        children: [
          Image(image: AssetImage(model.image,
        
          ), height: size.height * 0.5),
          Column(
            children: [
              Text(
                model.title,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                 
                ),
              ),

              Text(model.subTitle, textAlign: TextAlign.center),
            ],
          ),
          Text(
            model.counterText,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 50.0),
        ],
      ),
    );
  }
}
