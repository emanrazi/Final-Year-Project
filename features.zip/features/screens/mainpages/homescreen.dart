import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:fyp/src/features/screens/pages/PerRegisterPage.dart';
import 'package:fyp/src/features/screens/pages/loginPage.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String? emotion;
  double? confidence;
  bool detecting = false;
  File? selectedImage;

  /// Auth check
  bool get isGuestUser => Supabase.instance.client.auth.currentUser == null;

  /* ───────────────────────── COMMON EMOTION UI ───────────────────────── */
  Widget _emotionDetectionUI({Widget? bottomPrompt}) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 40),
        child: Column(
          children: [
            Text(
              "Detect your pet's emotion 🐾",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.teal.shade800,
              ),
            ),
            const SizedBox(height: 20),

            if (selectedImage != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Image.file(
                  selectedImage!,
                  height: 180,
                  fit: BoxFit.cover,
                ),
              ),
            const SizedBox(height: 20),

            ElevatedButton.icon(
              onPressed: pickEmotionImage,
              icon: const Icon(Icons.image),
              label: const Text("Select Image"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                foregroundColor: Colors.white,
                padding:
                    const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
              ),
            ),
            const SizedBox(height: 20),

            detecting
                ? const CircularProgressIndicator()
                : ElevatedButton.icon(
                    onPressed: detectEmotion,
                    icon: const Icon(Icons.psychology),
                    label: const Text("Detect Emotion"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal.shade700,
                      foregroundColor: Colors.white,
                      padding:
                          const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                  ),
            const SizedBox(height: 25),

            if (emotion != null)
              Card(
                color: Colors.teal.shade50,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                elevation: 5,
                child: Padding(
                  padding: const EdgeInsets.all(15),
                  child: Column(
                    children: [
                      Text(
                        "Emotion: $emotion",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.teal.shade900,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        confidence != null
                            ? "Confidence: ${(confidence! * 100).toStringAsFixed(1)}%"
                            : "Confidence: N/A",
                        style: TextStyle(color: Colors.teal.shade700),
                      ),
                    ],
                  ),
                ),
              ),

            const SizedBox(height: 20),
            if (bottomPrompt != null) bottomPrompt,
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  /* ───────────────────────── GUEST UI ───────────────────────── */
  Widget _buildGuestUI() {
    return _emotionDetectionUI(
      bottomPrompt: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: Colors.teal.shade100,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.teal.withOpacity(0.2),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: [
            Text(
              "Login to save your pet & emotion history 🐶",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.teal.shade900,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                Get.to(() => const Loginpage());
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                foregroundColor: Colors.white,
                padding:
                    const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
              ),
              child: const Text("Login / Signup"),
            ),
          ],
        ),
      ),
    );
  }

  /* ───────────────────── LOGGED-IN UI ───────────────────── */
  Widget _buildLoggedInUI() {
    return FutureBuilder<Map<String, dynamic>?>(

      future: getUserPet(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (!snapshot.hasData || snapshot.data == null) {
          return _emotionDetectionUI(
            bottomPrompt: Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Colors.teal.shade100,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.teal.withOpacity(0.2),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Text(
                    "Register your pet to save emotion history 🐕",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.teal.shade900,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: () {
                      Get.to(() => const PetRegisterPage());
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 40, vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                    child: const Text("Register Pet"),
                  ),
                ],
              ),
            ),
          );
        }

        return _emotionDetectionUI();
      },
    );
  }

  /* ───────────────────────── BACKEND METHODS ───────────────────────── */
  Future<Map<String, dynamic>?> getUserPet() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return null;

    return await Supabase.instance.client
        .from('pets')
        .select()
        .eq('user_id', userId)
        .order('created_at', ascending: false)
        .limit(1)
        .maybeSingle();
  }

  Future<void> pickEmotionImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);

    if (picked != null) {
      setState(() {
        selectedImage = File(picked.path);
      });
    }
  }

  /* ───────────────────────── FIXED DETECT EMOTION ───────────────────────── */
  Future<void> detectEmotion() async {
    if (selectedImage == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select an image first')),
      );
      return;
    }

    setState(() {
      detecting = true;
      emotion = null;
      confidence = null;
    });

    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('http://10.0.2.2:5000/emotionPrediction'),
      );

      request.files.add(
        await http.MultipartFile.fromPath('image', selectedImage!.path),
      );

      final response = await request.send();
      final responseBody = await response.stream.bytesToString();
      final data = jsonDecode(responseBody);

      setState(() {
        // ✅ Safe null handling
        emotion = data['emotion'] ?? 'Unknown';
        confidence = (data['confidence'] != null)
            ? (data['confidence'] as num).toDouble()
            : 0.0;
      });
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      setState(() => detecting = false);
    }
  }

  /* ───────────────────────── BUILD ───────────────────────── */
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal.shade50,
      body: isGuestUser ? _buildGuestUI() : _buildLoggedInUI(),
    );
  }
}
