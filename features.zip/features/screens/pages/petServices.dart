import 'package:supabase/supabase.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PetService {
  final SupabaseClient _supabase = Supabase.instance.client;

  Future<void> registerPet({
    required String name,
    required String type,
    required int age,
    required String imageUrl,
  }) async {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) throw Exception("User not logged in");

    try {
      await _supabase.from('pets').insert({
        'user_id': userId,
        'name': name,
        'type': type,
        'age': age,
        'image_url': imageUrl,
      });
    } catch (e) {
      throw Exception('Failed to register pet: $e');
    }
  }
}
