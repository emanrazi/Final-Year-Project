import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class UserPetsPage extends StatelessWidget {
  const UserPetsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;

    if (user == null) {
      return const Center(child: Text("No user logged in"));
    }

    return Scaffold(
      appBar: AppBar(title: const Text("My Pets")),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: supabase
            .from('pets')
            .stream(primaryKey: ['id']) // Use the primary key of your table
            .eq('user_id', user.id), // Only fetch pets for this user
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final pets = snapshot.data!;
          if (pets.isEmpty) {
            return const Center(child: Text("No Pets Registered"));
          }

          return ListView.builder(
            itemCount: pets.length,
            itemBuilder: (context, index) {
              final pet = pets[index];
              return ListTile(
                title: Text(pet['name'] ?? 'No Name'),
                subtitle: Text("${pet['type']} - ${pet['breed']}"),
              );
            },
          );
        },
      ),
    );
  }
}
