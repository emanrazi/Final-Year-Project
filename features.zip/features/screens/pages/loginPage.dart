import 'package:flutter/material.dart';
import 'package:fyp/src/features/models/auth_service.dart';
import 'package:fyp/src/features/screens/pages/intropage.dart';
import 'package:get/get.dart';
import 'package:fyp/src/features/screens/pages/signupPage.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class Loginpage extends StatefulWidget {
  const Loginpage({super.key});

  @override
  State<Loginpage> createState() => _LoginpageState();
}

class _LoginpageState extends State<Loginpage> {
  final TextEditingController email = TextEditingController();
  final TextEditingController password = TextEditingController();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  bool loading = false;
  final supabase = Supabase.instance.client;

  String userName = '';

  /// Login function
  void loginNow() async {
    final AuthService _authService = AuthService();
    if (!formKey.currentState!.validate()) return;

    setState(() => loading = true);

    try {
      // Sign in
      await _authService.signInWithEmailPassword(
        email.text.trim(),
        password.text.trim(),
      );

      // Fetch user name from Supabase profiles table
      final user = supabase.auth.currentUser;
      if (user != null) {
        final data =
            await supabase
                .from('profiles')
                .select('name')
                .eq('id', user.id)
                .maybeSingle();
        userName = data?['name'] ?? 'Guest';
      }

      // Navigate to IntroHomePage after login
      Get.offAll(() => const IntroHomePage());
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Login failed: $e')));
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    Color hintColor = Colors.teal; // Label color

    return Scaffold(
      backgroundColor: Colors.teal.shade50, // Light teal background
      resizeToAvoidBottomInset: true,
      body:
          loading
              ? const Center(child: CircularProgressIndicator())
              : SingleChildScrollView(
                child: Stack(
                  children: [
                    // Background Image
                    Column(
                      children: [
                        Image.asset(
                          'images/download.png',
                          height: MediaQuery.of(context).size.height,
                          fit: BoxFit.cover,
                        ),
                      ],
                    ),

                    // Login Form
                    Padding(
                      padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.height / 3.6,
                        left: 20,
                        right: 20,
                      ),
                      child: Material(
                        elevation: 3,
                        borderRadius: BorderRadius.circular(20),
                        child: Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Form(
                            key: formKey,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                const Text(
                                  'Welcome Back',
                                  style: TextStyle(
                                    color: Colors.teal,
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 20),

                                // Email
                                _buildField(
                                  label: "Email",
                                  controller: email,
                                  hint: "Enter Email",
                                  icon: Icons.mail_outline,
                                  validator:
                                      (v) =>
                                          v == null || v.isEmpty
                                              ? "Please enter your email"
                                              : null,
                                  hintColor: hintColor,
                                ),
                                const SizedBox(height: 15),

                                // Password
                                _buildField(
                                  label: "Password",
                                  controller: password,
                                  hint: "Enter Password",
                                  icon: Icons.password_outlined,
                                  isPassword: true,
                                  validator:
                                      (v) =>
                                          v == null || v.length < 6
                                              ? "Password must be at least 6 characters"
                                              : null,
                                  hintColor: hintColor,
                                ),
                                const SizedBox(height: 10),

                                // Forgot password
                                Align(
                                  alignment: Alignment.centerRight,
                                  child: TextButton(
                                    onPressed: () {
                                      print("Forgot Password tapped");
                                    },
                                    child: Text(
                                      "Forgot Password?",
                                      style: TextStyle(
                                        color: Colors.teal.shade700,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 10),

                                // Login Button
                                SizedBox(
                                  width: 200,
                                  height: 45,
                                  child: ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.teal,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                    ),
                                    onPressed: loginNow,
                                    child: const Text(
                                      'Log In',
                                      style: TextStyle(color: Colors.white),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 20),
                                const SizedBox(height: 15),

                                // Guest mode
                                TextButton(
                                  onPressed: () {
                                    Get.offAll(() => const IntroHomePage());
                                  },
                                  child: Text(
                                    "Continue as Guest",
                                    style: TextStyle(
                                      color: Colors.teal.shade700,
                                      fontWeight: FontWeight.w600,
                                      decoration: TextDecoration.underline,
                                    ),
                                  ),
                                ),

                                // Signup redirect
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    const Text("Don't have an account? "),
                                    GestureDetector(
                                      onTap: () {
                                        Get.to(
                                          () => const SignUpPage(),
                                          duration: const Duration(
                                            milliseconds: 500,
                                          ),
                                          transition: Transition.leftToRight,
                                        );
                                      },
                                      child: Text(
                                        'Sign Up',
                                        style: TextStyle(
                                          color: Colors.teal.shade700,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
    );
  }

  /// Helper widget for text fields
  Widget _buildField({
    required String label,
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    required String? Function(String?) validator,
    bool isPassword = false,
    Color hintColor = Colors.teal,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(color: hintColor), // Label color teal
        ),
        const SizedBox(height: 5),
        Container(
          decoration: BoxDecoration(
            color: Colors.teal.shade50,
            borderRadius: BorderRadius.circular(10),
          ),
          child: TextFormField(
            controller: controller,
            obscureText: isPassword,
            validator: validator,
            style: const TextStyle(color: Colors.black), // input text black
            decoration: InputDecoration(
              border: InputBorder.none,
              hintText: hint,
              hintStyle: const TextStyle(color: Colors.black45), // hint gray
              prefixIcon: Icon(icon, color: Colors.teal),
            ),
          ),
        ),
      ],
    );
  }
}
