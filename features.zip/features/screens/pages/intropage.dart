import 'package:flutter/material.dart';
import 'package:fyp/src/features/screens/mainpages/homescreen.dart';
import 'package:get/get.dart';
import 'loginPage.dart';
import 'petServices.dart';
import 'PerRegisterPage.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class IntroHomePage extends StatelessWidget {
  const IntroHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;

    Future<void> _confirmLogout() async {
      final shouldLogout = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Confirm Logout'),
          content: const Text('Do you want to logout?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Logout'),
            ),
          ],
        ),
      );

      if (shouldLogout == true) {
        await supabase.auth.signOut();
        Get.offAll(() => const Loginpage());
      }
    }

    Future<Map<String, dynamic>?> _getUserPet() async {
      if (user == null) return null;

      return await supabase
          .from('pets')
          .select()
          .eq('user_id', user.id)
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();
    }

    return Scaffold(
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(color: Colors.teal),
              child: FutureBuilder<Map<String, dynamic>?>(
                future: _getUserPet(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                      child: CircularProgressIndicator(color: Colors.white),
                    );
                  }

                  final pet = snapshot.data;
                  final petName = pet?['name'] ?? 'My Pet';
                  final petImageUrl = pet?['image_url'];

                  return Row(
                    children: [
                      CircleAvatar(
                        radius: 35,
                        backgroundColor: Colors.white,
                        backgroundImage:
                            (petImageUrl != null &&
                                    petImageUrl.toString().isNotEmpty)
                                ? NetworkImage(petImageUrl)
                                : null,
                        child: (petImageUrl == null ||
                                petImageUrl.toString().isEmpty)
                            ? const Icon(Icons.pets,
                                size: 30, color: Colors.teal)
                            : null,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              petName,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              user?.email ?? '',
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 14,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),

            ListTile(
              leading: const Icon(Icons.home),
              title: const Text('Home'),
              onTap: () => Get.back(),
            ),

            ListTile(
              leading: const Icon(Icons.pets),
              title: const Text('Detect Emotion'),
              onTap: () {
                Get.back();
                Get.to(() => const HomeScreen());
              },
            ),

            ListTile(
              leading: const Icon(Icons.info_outline),
              title: const Text('About App'),
              onTap: () {
                Get.back();
                _showAboutDialog(context);
              },
            ),

            const Divider(),

            if (user == null)
              ListTile(
                leading: const Icon(Icons.login),
                title: const Text('Login / Signup'),
                onTap: () {
                  Get.back();
                  Get.to(() => const Loginpage());
                },
              )
            else
              ListTile(
                leading: const Icon(Icons.logout),
                title: const Text('Logout'),
                onTap: _confirmLogout,
              ),
          ],
        ),
      ),

      appBar: AppBar(
        title: const Text('Pet Emotion'),
        centerTitle: true,
      ),

      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              elevation: 5,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    const Icon(Icons.camera_alt,
                        size: 60, color: Colors.teal),
                    const SizedBox(height: 12),
                    const Text(
                      'Detect Pet Emotion',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Scan your pet and detect emotions instantly',
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () {
                        Get.to(() => const HomeScreen());
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        'Start Detection',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: ListTile(
                leading: const Icon(Icons.favorite, color: Colors.red),
                title: const Text('Pet Care Tips'),
                subtitle: const Text('Daily tips to keep your pet healthy'),
                trailing:
                    const Icon(Icons.arrow_forward_ios, size: 16),
                onTap: () {
                  _showPetCareTips(context);
                },
              ),
            ),

            const SizedBox(height: 10),

            user != null
                ? Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      leading: const Icon(Icons.assignment_turned_in,
                          color: Colors.teal),
                      title: const Text('Register Your Pet'),
                      subtitle: const Text(
                          'Add your pet and start tracking their health'),
                      trailing:
                          const Icon(Icons.arrow_forward_ios, size: 16),
                      onTap: () {
                        Get.to(() => const PetRegisterPage());
                      },
                    ),
                  )
                : const SizedBox(),
          ],
        ),
      ),
    );
  }

  static void _showAboutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('About App'),
        content: const Text(
          'This app helps you detect your pet’s emotions using AI.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  static void _showPetCareTips(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Pet Care Tips'),
        content: const Text(
          '• Fresh water daily\n• Vet checkups\n• Exercise\n• Love ❤️',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Got it'),
          ),
        ],
      ),
    );
  }
}
