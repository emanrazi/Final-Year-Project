import 'dart:io';
import 'package:flutter/material.dart';
import 'package:fyp/src/features/models/auth_service.dart';
import 'package:fyp/src/features/screens/mainpages/homescreen.dart';
import 'package:fyp/src/features/screens/pages/petServices.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:image_picker/image_picker.dart';

class PetRegisterPage extends StatefulWidget {
  const PetRegisterPage({super.key});

  @override
  State<PetRegisterPage> createState() => _PetRegisterPageState();
}

class _PetRegisterPageState extends State<PetRegisterPage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController typeController = TextEditingController();
  final TextEditingController ageController = TextEditingController();

  File? petImage;
  bool loading = true;

  final StorageService storageService = StorageService();
  final PetService petService = PetService();

  @override
  void initState() {
    super.initState();
    _checkExistingPet();
  }

  void _checkExistingPet() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;

    final response =
        await Supabase.instance.client
            .from('pets')
            .select()
            .eq('user_id', userId)
            .limit(1)
            .maybeSingle();

    if (response != null) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HomeScreen()),
      );
    } else {
      setState(() => loading = false);
    }
  }

  void pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => petImage = File(picked.path));
    }
  }

  void registerPet() async {
    if (nameController.text.isEmpty ||
        typeController.text.isEmpty ||
        ageController.text.isEmpty ||
        petImage == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please fill all fields and pick an image'),
        ),
      );
      return;
    }

    setState(() => loading = true);

    try {
      final imageUrl = await storageService.uploadPetImage(
        petImage!,
        Supabase.instance.client.auth.currentUser!.id,
      );

      await petService.registerPet(
        name: nameController.text.trim(),
        type: typeController.text.trim(),
        age: int.parse(ageController.text.trim()),
        imageUrl: imageUrl,
      );

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pet registered successfully')),
      );

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HomeScreen()),
      );
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        title: const Text(
          'Register Your Pet',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.teal, // Intro screen green
        centerTitle: true,
      ),
      body:
          loading
              ? const Center(child: CircularProgressIndicator())
              : SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Image picker with shadow & rounded
                    GestureDetector(
                      onTap: pickImage,
                      child: Container(
                        height: 160,
                        width: 160,
                        decoration: BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.teal.withOpacity(0.2),
                              blurRadius: 10,
                              offset: const Offset(0, 5),
                            ),
                          ],
                          image:
                              petImage != null
                                  ? DecorationImage(
                                    image: FileImage(petImage!),
                                    fit: BoxFit.cover,
                                  )
                                  : null,
                        ),
                        child:
                            petImage == null
                                ? const Icon(
                                  Icons.add_a_photo,
                                  size: 50,
                                  color: Colors.teal,
                                )
                                : null,
                      ),
                    ),
                    const SizedBox(height: 30),

                    // TextFields with icons
                    _buildTextField(
                      'Pet Name',
                      nameController,
                      icon: Icons.pets,
                      color: Colors.teal,
                    ),
                    const SizedBox(height: 15),
                    _buildTextField(
                      'Pet Type',
                      typeController,
                      icon: Icons.category,
                      color: Colors.teal,
                    ),
                    const SizedBox(height: 15),
                    _buildTextField(
                      'Pet Age',
                      ageController,
                      icon: Icons.cake,
                      keyboardType: TextInputType.number,
                      color: Colors.teal,
                    ),
                    const SizedBox(height: 30),

                    // Register button
                    ElevatedButton(
                      onPressed: registerPet,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 40,
                          vertical: 15,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                      child: const Text(
                        'Register Pet',
                        style: TextStyle(fontSize: 18, color: Colors.white),
                      ),
                    ),
                    const SizedBox(height: 50),
                  ],
                ),
              ),
    );
  }

  Widget _buildTextField(
    String label,
    TextEditingController controller, {
    TextInputType keyboardType = TextInputType.text,
    required IconData icon,
    required Color color,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: color),
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 15,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}
