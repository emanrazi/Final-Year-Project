import 'package:flutter/material.dart';
import 'package:fyp/src/features/models/auth_service.dart';
import 'package:fyp/src/features/screens/pages/intropage.dart';
import 'package:get/get.dart';
import 'package:fyp/src/features/screens/pages/loginPage.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Available roles
const List<String> roleOptions = ['pet Owner', 'vet'];

extension StringCap on String {
  String capitalizeFirst() =>
      isEmpty ? this : this[0].toUpperCase() + substring(1);
}

class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  // Controllers
  final TextEditingController name = TextEditingController();
  final TextEditingController email = TextEditingController();
  final TextEditingController password = TextEditingController();

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  bool loading = false;
  String selectedRole = roleOptions[0];

  final supabase = Supabase.instance.client;
  final AuthService _authService = AuthService();

  /// Supabase registration
  void registerNow() async {
    if (!formKey.currentState!.validate()) return;

    final userEmail = email.text.trim();
    if (!RegExp(r"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$").hasMatch(userEmail)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter a valid email")),
      );
      setState(() => loading = false);
      return;
    }

    final userPassword = password.text.trim();
    final userName = name.text.trim();

    setState(() => loading = true);

    try {
      await _authService.signUpWithEmailPassword(
        userEmail,
        userPassword,
        userName,
        selectedRole,
      );

      Get.offAll(() => const IntroHomePage());
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void forgotPassword() {
    Get.snackbar(
      "Forgot Password",
      "This feature is not implemented yet.",
      snackPosition: SnackPosition.BOTTOM,
    );
  }

  @override
  Widget build(BuildContext context) {
    Color primaryColor = Colors.teal;

    return Scaffold(
      backgroundColor: Colors.teal.shade50,
      body:
          loading
              ? const Center(child: CircularProgressIndicator())
              : GestureDetector(
                onTap: () => FocusScope.of(context).unfocus(),
                child: Stack(
                  children: [
                    /// Background Image
                    Positioned.fill(
                      child: Image.asset(
                        'images/download.png',

                        fit: BoxFit.cover,
                      ),
                    ),

                    /// Form Container
                    SafeArea(
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical: 80,
                          ),
                          child: Material(
                            elevation: 5,
                            borderRadius: BorderRadius.circular(20),
                            child: Container(
                              padding: const EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Form(
                                key: formKey,
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.stretch,
                                  children: [
                                    Center(
                                      child: Text(
                                        'Create Account',
                                        style: TextStyle(
                                          fontSize: 22,
                                          fontWeight: FontWeight.bold,
                                          color: primaryColor,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 20),

                                    // Name
                                    _buildField(
                                      label: "Name",
                                      controller: name,
                                      hint: "Enter Name",
                                      icon: Icons.person_outline,
                                    ),
                                    const SizedBox(height: 15),

                                    // Email
                                    _buildField(
                                      label: "Email",
                                      controller: email,
                                      hint: "Enter Email",
                                      icon: Icons.mail_outline,
                                    ),
                                    const SizedBox(height: 15),

                                    // Password
                                    _buildField(
                                      label: "Password",
                                      controller: password,
                                      hint: "Enter Password",
                                      icon: Icons.password_outlined,
                                      isPassword: true,
                                    ),

                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: TextButton(
                                        onPressed: forgotPassword,
                                        child: Text(
                                          "Forgot Password?",
                                          style: TextStyle(
                                            color: primaryColor,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 10),

                                    _roleSelector(),
                                    const SizedBox(height: 15),

                                    SizedBox(
                                      height: 45,
                                      child: ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: primaryColor,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                              30,
                                            ),
                                          ),
                                        ),
                                        onPressed: loading ? null : registerNow,
                                        child: const Text(
                                          'Sign Up',
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 15),

                                    Row(
                                      children: const [
                                        Expanded(child: Divider()),
                                        Padding(
                                          padding: EdgeInsets.symmetric(
                                            horizontal: 10,
                                          ),
                                          child: Text("OR"),
                                        ),
                                        Expanded(child: Divider()),
                                      ],
                                    ),
                                    const SizedBox(height: 10),

                                    SizedBox(
                                      height: 45,
                                      child: OutlinedButton.icon(
                                        icon: Image.asset(
                                          "images/google.png",
                                          height: 24,
                                        ),
                                        label: const Text(
                                          "Sign Up with Google",
                                          style: TextStyle(
                                            color: Color.fromARGB(
                                              255,
                                              57,
                                              53,
                                              53,
                                            ),
                                          ),
                                        ),
                                        onPressed: () {},
                                        style: OutlinedButton.styleFrom(
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                              30,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 10),

                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        const Text("Already have an account? "),
                                        GestureDetector(
                                          onTap:
                                              () => Get.to(
                                                () => const Loginpage(),
                                              ),
                                          child: Text(
                                            "Login",
                                            style: TextStyle(
                                              color: primaryColor,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
    );
  }

  // Role selector widget
  Widget _roleSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Register as'),
        const SizedBox(height: 5),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            color: Colors.teal.shade50,
            borderRadius: BorderRadius.circular(10),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: selectedRole,
              items:
                  roleOptions
                      .map(
                        (r) => DropdownMenuItem(
                          value: r,
                          child: Text(StringCap(r).capitalizeFirst()),
                        ),
                      )
                      .toList(),
              onChanged: (v) {
                if (v == null) return;
                setState(() => selectedRole = v);
              },
            ),
          ),
        ),
      ],
    );
  }

  /// Helper widget for text fields
  Widget _buildField({
    required String label,
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool isPassword = false,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextFormField(
        controller: controller,
        obscureText: isPassword,
        validator: (v) {
          if (v == null || v.isEmpty) return "Please enter $label";
          if (isPassword && v.length < 6) {
            return "Password must be at least 6 characters";
          }
          return null;
        },
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          prefixIcon: Icon(icon, color: Colors.teal),
          filled: true,
          fillColor: Colors.teal.shade50,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          contentPadding: const EdgeInsets.symmetric(
            vertical: 18,
            horizontal: 16,
          ),
        ),
      ),
    );
  }
}
