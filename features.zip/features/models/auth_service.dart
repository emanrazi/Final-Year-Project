import 'dart:io';

import 'package:supabase/supabase.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  final SupabaseClient _supabase = Supabase.instance.client;

  // SIGN UP with email, password, name, role
  Future<void> signUpWithEmailPassword(
    String email,
    String password,
    String name,
    String role,
  ) async {
    // 1️⃣ Sign up the user
    final response = await _supabase.auth.signUp(
      email: email,
      password: password,
    );

    final user = response.user;

    if (user == null) {
      throw Exception("User not created");
    }

    // 2️⃣ Wait until session is fully initialized
    await _waitForSession();

    // 3️⃣ Insert profile with RLS enabled
    final currentUser = _supabase.auth.currentUser;
    if (currentUser == null) throw Exception("User session not ready");

    await _supabase.from('profiles').insert({
      'auth_id': currentUser.id,
      'name': name,
      'email': email,
      'role': role,
    });
  }

  // Wait for the session to be initialized
  Future<void> _waitForSession() async {
    int tries = 0;
    while (_supabase.auth.currentUser == null && tries < 5) {
      await Future.delayed(const Duration(milliseconds: 500));
      tries++;
    }
  }

  // SIGN IN with email & password
  Future<void> signInWithEmailPassword(String email, String password) async {
    final response = await _supabase.auth.signInWithPassword(
      email: email,
      password: password,
    );

    if (response.user == null) {
      throw Exception("Login failed");
    }
  }

  // SIGN OUT
  Future<void> signOut() async {
    await _supabase.auth.signOut();
  }

  // GET CURRENT USER EMAIL
  String? getCurrentUserEmail() {
    final session = _supabase.auth.currentSession;
    final user = session?.user;
    return user?.email;
  }
}

class StorageService {
  final SupabaseClient _supabase = Supabase.instance.client;

  Future<String> uploadPetImage(File file, String userId) async {
    final fileName =
        '${DateTime.now().millisecondsSinceEpoch}_${file.path.split('/').last}';

    try {
      // Upload file
      await _supabase.storage
          .from('pet_images')
          .upload('$userId/$fileName', file);

      // Get public URL
      final publicUrl = _supabase.storage
          .from('pet_images')
          .getPublicUrl('$userId/$fileName');

      return publicUrl;
    } catch (e) {
      throw Exception('Image upload failed: $e');
    }
  }
}
